import os
import re
from lxml import html

ROOT_DIR = 'c:/users/vaidhy/Development/scipy/HP_MoR'
titlep = re.compile(r'Chapter\s+(\d+): (.*?) a Harry')

for f in os.listdir(ROOT_DIR):
    tree = html.parse(ROOT_DIR + os.sep + f)
    desc = tree.xpath('/html/head/meta[@name="description"]')[0].attrib['content']
    titletext = tree.xpath('/html/head/title')[0].text
    print titletext
    match = titlep.search(titletext)
    chapter, title = match.group(1), match.group(2).strip(',')
    content = tree.xpath('//div[@class="storytext"]')[0].text_content()
    print "Chapter : " , chapter
    print "Title : " , title
    print "Desc : " , desc
    print "Length : " , len(content)