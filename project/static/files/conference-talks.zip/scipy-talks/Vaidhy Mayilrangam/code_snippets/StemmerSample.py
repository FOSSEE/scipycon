import nltk

stemmer = nltk.PorterStemmer()
print stemmer.stem('disappearance')
print

words = ['disappear', 'disappearing', 'disappeared', 'disappears', 'disappearance']
for word in words: print stemmer.stem(word)
print

words = ['floo', 'flooing', 'flooed', 'floos']
for word in words: print stemmer.stem(word)